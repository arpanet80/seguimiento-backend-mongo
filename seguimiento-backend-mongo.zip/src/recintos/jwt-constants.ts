export const jwtConstants = {
    secret: 'jwt-secret'
}